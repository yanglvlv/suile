#!/usr/bin/env python3
"""
CodeBuddy/WorkBuddy 跨对话搜索引擎
搜索所有工作区的所有对话历史中的消息内容
支持 CodeBuddy 和 WorkBuddy 两个平台

@version: 1.2.0
@author: christoxu
@date: 2026-03-26

功能：
- 关键词搜索（支持多关键词 AND 逻辑）
- 正则表达式搜索
- 按工作区/日期/角色过滤
- 按平台过滤（CodeBuddy/WorkBuddy/全部）
- 输出匹配消息的上下文（对话标题、工作区、时间等）
- 搜索项目级记忆文件（.codebuddy/memory/、.workbuddy/memory/ 和 MEMORY.md）
- 跨平台支持（Windows/macOS/Linux）

用法：
  python3 search_conversations.py <关键词> [选项]

选项：
  --regex           使用正则表达式模式
  --platform <p>    只搜索指定平台 (codebuddy/workbuddy)，默认全部
  --role <role>     只搜索指定角色 (user/assistant)
  --days <N>        只搜索最近 N 天的对话
  --limit <N>       最多返回 N 条结果 (默认 30)
  --context <N>     显示匹配行前后 N 条消息 (默认 0)
  --workspace <kw>  只搜索工作区名包含 kw 的对话
  --memory          同时搜索项目级记忆文件
  --memory-only     只搜索记忆文件（跳过对话）
  --list            列出所有工作区和对话（不搜索）
  --verbose         显示详细信息
  --json            输出 JSON 格式
"""

import json
import os
import re
import sys
import argparse
import base64
import platform
from datetime import datetime, timezone, timedelta
from pathlib import Path


# ============ 跨平台路径支持 ============
def get_platform_paths():
    """根据操作系统返回数据目录路径配置"""
    system = platform.system()
    
    if system == "Windows":
        # Windows: 使用 %APPDATA% 环境变量
        appdata = os.environ.get("APPDATA", os.path.expanduser("~/AppData/Roaming"))
        return {
            "codebuddy": {
                "name": "CodeBuddy",
                "ext_data": os.path.join(appdata, "CodeBuddyExtension", "Data"),
                "ide_storage": os.path.join(appdata, "CodeBuddy CN", "User", "globalStorage",
                                           "tencent-cloud.coding-copilot", "genie-history"),
            },
            "workbuddy": {
                "name": "WorkBuddy",
                "ext_data": os.path.join(appdata, "WorkBuddyExtension", "Data"),
                "ide_storage": None,
            },
        }
    elif system == "Darwin":
        # macOS
        return {
            "codebuddy": {
                "name": "CodeBuddy",
                "ext_data": "~/Library/Application Support/CodeBuddyExtension/Data",
                "ide_storage": "~/Library/Application Support/CodeBuddy CN/User/globalStorage/"
                               "tencent-cloud.coding-copilot/genie-history",
            },
            "workbuddy": {
                "name": "WorkBuddy",
                "ext_data": "~/Library/Application Support/WorkBuddyExtension/Data",
                "ide_storage": None,
            },
        }
    elif system == "Linux":
        # Linux: 通常在 ~/.config 或 ~/.local/share
        home = os.path.expanduser("~")
        config_dir = os.environ.get("XDG_CONFIG_HOME", os.path.join(home, ".config"))
        return {
            "codebuddy": {
                "name": "CodeBuddy",
                "ext_data": os.path.join(config_dir, "CodeBuddyExtension", "Data"),
                "ide_storage": os.path.join(config_dir, "CodeBuddy CN", "User", "globalStorage",
                                           "tencent-cloud.coding-copilot", "genie-history"),
            },
            "workbuddy": {
                "name": "WorkBuddy",
                "ext_data": os.path.join(config_dir, "WorkBuddyExtension", "Data"),
                "ide_storage": None,
            },
        }
    else:
        # 未知系统，尝试 macOS 路径作为默认
        print(f"⚠️ 未知操作系统: {system}，尝试 macOS 路径")
        return {
            "codebuddy": {
                "name": "CodeBuddy",
                "ext_data": "~/Library/Application Support/CodeBuddyExtension/Data",
                "ide_storage": "~/Library/Application Support/CodeBuddy CN/User/globalStorage/"
                               "tencent-cloud.coding-copilot/genie-history",
            },
            "workbuddy": {
                "name": "WorkBuddy",
                "ext_data": "~/Library/Application Support/WorkBuddyExtension/Data",
                "ide_storage": None,
            },
        }


# 动态获取平台配置
SUPPORTED_PLATFORMS = get_platform_paths()


# ============ 自动发现用户 ID ============
def find_user_ids(ext_data_dir):
    """自动发现指定数据目录下的所有用户 ID"""
    if not os.path.isdir(ext_data_dir):
        return []
    
    user_ids = []
    for name in os.listdir(ext_data_dir):
        if name in ("Public", "default", ".DS_Store"):
            continue
        full = os.path.join(ext_data_dir, name)
        if os.path.isdir(full):
            user_ids.append(name)
    return user_ids


def get_history_bases(platform_filter=None):
    """获取所有 history 基目录，支持按平台过滤
    
    Args:
        platform_filter: None 表示全部平台，"codebuddy" 或 "workbuddy" 表示只搜索该平台
    
    Returns:
        list of (base_path, platform_key) 元组
    """
    results = []
    
    for plat_key, plat_info in SUPPORTED_PLATFORMS.items():
        if platform_filter and platform_filter != plat_key:
            continue
        
        ext_data = os.path.expanduser(plat_info["ext_data"])
        if not os.path.isdir(ext_data):
            continue
        
        for user_id in find_user_ids(ext_data):
            for ide_type_dir in Path(ext_data, user_id).iterdir():
                if not ide_type_dir.is_dir():
                    continue
                for inner_dir in ide_type_dir.iterdir():
                    if not inner_dir.is_dir():
                        continue
                    history = inner_dir / "history"
                    if history.is_dir():
                        results.append((str(history), plat_key))
        
        # 也检查 default 用户
        default_base = os.path.join(ext_data, "default")
        if os.path.isdir(default_base):
            for ide_dir in Path(default_base).iterdir():
                if not ide_dir.is_dir():
                    continue
                for inner in ide_dir.iterdir():
                    if not inner.is_dir():
                        continue
                    history = inner / "history"
                    if history.is_dir():
                        results.append((str(history), plat_key))
    
    return results


# ============ 工作区路径解码 ============
_ws_hash_to_path_cache = None

def build_workspace_hash_map():
    """构建 workspace hash → 工作区路径 的映射表（多平台）"""
    global _ws_hash_to_path_cache
    if _ws_hash_to_path_cache is not None:
        return _ws_hash_to_path_cache
    
    import hashlib
    mapping = {}
    
    for plat_key, plat_info in SUPPORTED_PLATFORMS.items():
        genie = os.path.expanduser(plat_info["ide_storage"]) if plat_info["ide_storage"] else None
        if not genie or not os.path.isdir(genie):
            continue
        
        for b64_dir in os.listdir(genie):
            try:
                decoded_path = base64.b64decode(b64_dir).decode('utf-8')
                md5_hash = hashlib.md5(decoded_path.encode()).hexdigest()
                mapping[md5_hash] = decoded_path
            except Exception:
                pass
    
    _ws_hash_to_path_cache = mapping
    return mapping


def get_workspace_display_name(ws_hash, genie_history_dir=None):
    """获取工作区的显示名称"""
    mapping = build_workspace_hash_map()
    
    if ws_hash in mapping:
        full_path = mapping[ws_hash]
        # 使用 os.path 跨平台处理路径
        full_path = full_path.rstrip(os.sep).replace('\\', '/')
        parts = full_path.split('/')
        name = parts[-1] if parts else ws_hash[:12]
        
        # 如果名称是纯时间戳格式，尝试用父目录补充
        if re.match(r'^\d{14}$', name) and len(parts) >= 2:
            parent = parts[-2]
            if parent != "CodeBuddy":
                return f"{parent}/{name}"
            else:
                # 用日期格式化
                try:
                    dt = datetime.strptime(name, "%Y%m%d%H%M%S")
                    return f"会话_{dt.strftime('%m-%d %H:%M')}"
                except:
                    return name
        return name
    
    return ws_hash[:12] + "…"


# ============ 消息解析 ============
def extract_text_from_message(msg_data):
    """从消息 JSON 中提取纯文本内容"""
    role = msg_data.get("role", "")
    raw = msg_data.get("message", "")
    
    if not raw:
        # 某些格式直接有 text/content 字段
        return role, msg_data.get("text", "") or msg_data.get("content", "")
    
    try:
        inner = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        # 不是 JSON，直接清理 HTML/XML 标签
        clean = re.sub(r'<[^>]+>', '', raw).strip()
        return role, clean
    
    content = inner.get("content", [])
    
    if isinstance(content, str):
        text = content
    elif isinstance(content, list):
        text_parts = []
        for c in content:
            if isinstance(c, dict):
                if c.get("type") == "text":
                    text_parts.append(c.get("text", ""))
                elif c.get("type") == "tool-call":
                    tool_name = c.get("toolName", "")
                    args = c.get("args", {})
                    if isinstance(args, dict):
                        text_parts.append(f"[调用工具: {tool_name}({json.dumps(args, ensure_ascii=False)[:100]})]")
                elif c.get("type") == "tool-result":
                    pass  # 通常太长，跳过
        text = "\n".join(text_parts)
    else:
        text = str(content)
    
    # 提取 user_query 内容（如果存在）
    uq_match = re.search(r'<user_query>\s*(.*?)\s*</user_query>', text, re.DOTALL)
    if uq_match:
        user_query = uq_match.group(1).strip()
        # 也保留 user_query 外面的有用上下文
        rest = re.sub(r'<user_query>.*?</user_query>', '', text, flags=re.DOTALL)
        rest = re.sub(r'<[^>]+>', '', rest).strip()
        if rest and len(rest) > 20:
            return role, f"{user_query}\n---\n{rest}"
        return role, user_query
    
    # 清理各类 XML 标签
    clean = re.sub(r'<[^>]+>', '', text).strip()
    # 压缩连续空白
    clean = re.sub(r'\n{3,}', '\n\n', clean)
    return role, clean


# ============ 搜索功能 ============
def search_in_text(text, pattern, use_regex=False):
    """在文本中搜索，返回匹配的行和高亮位置"""
    if not text:
        return []
    
    matches = []
    lines = text.split('\n')
    
    for i, line in enumerate(lines):
        if use_regex:
            try:
                if re.search(pattern, line, re.IGNORECASE):
                    matches.append((i, line.strip()))
            except re.error:
                pass
        else:
            # 多关键词 AND 逻辑
            keywords = pattern.lower().split()
            line_lower = line.lower()
            if all(kw in line_lower for kw in keywords):
                matches.append((i, line.strip()))
    
    return matches


def load_conversation_index(ws_path):
    """加载工作区的对话索引"""
    index_path = os.path.join(ws_path, "index.json")
    if not os.path.exists(index_path):
        return {"conversations": []}
    try:
        with open(index_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"conversations": []}


def get_conversation_messages(conv_dir):
    """获取对话目录中的所有消息（按顺序）"""
    # 读取对话级 index.json 获取消息顺序
    conv_index_path = os.path.join(conv_dir, "index.json")
    msg_order = []
    
    if os.path.exists(conv_index_path):
        try:
            with open(conv_index_path, "r", encoding="utf-8") as f:
                ci = json.load(f)
            messages = ci.get("messages", [])
            if isinstance(messages, list):
                for m in messages:
                    if isinstance(m, dict) and "id" in m:
                        msg_order.append(m["id"])
        except Exception:
            pass
    
    # 如果没有顺序信息，按文件名排序
    msgs_dir = os.path.join(conv_dir, "messages")
    if not os.path.isdir(msgs_dir):
        return []
    
    results = []
    if msg_order:
        for msg_id in msg_order:
            msg_file = os.path.join(msgs_dir, f"{msg_id}.json")
            if os.path.exists(msg_file):
                try:
                    with open(msg_file, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    data["_msg_id"] = msg_id
                    results.append(data)
                except Exception:
                    pass
    else:
        for f in sorted(os.listdir(msgs_dir)):
            if not f.endswith('.json') or f.startswith('.'):
                continue
            try:
                with open(os.path.join(msgs_dir, f), "r", encoding="utf-8") as fh:
                    data = json.load(fh)
                data["_msg_id"] = f.replace('.json', '')
                results.append(data)
            except Exception:
                pass
    
    return results


def search_conversations(args):
    """主搜索函数"""
    pattern = " ".join(args.keywords) if args.keywords else ""
    
    if not pattern and not args.list and not args.memory_only:
        print("❌ 请提供搜索关键词")
        return
    
    platform_filter = getattr(args, 'platform', None)
    history_bases = get_history_bases(platform_filter)
    if not history_bases:
        print("❌ 未找到对话历史目录")
        system = platform.system()
        if system == "Windows":
            print("   预期路径: %APPDATA%\\{CodeBuddy,WorkBuddy}Extension\\Data\\")
        elif system == "Linux":
            print("   预期路径: ~/.config/{CodeBuddy,WorkBuddy}Extension/Data/")
        else:
            print("   预期路径: ~/Library/Application Support/{CodeBuddy,WorkBuddy}Extension/Data/")
        return
    
    # 日期过滤
    date_cutoff = None
    if args.days:
        date_cutoff = datetime.now(timezone.utc) - timedelta(days=args.days)
    
    results = []
    total_conversations = 0
    total_messages_scanned = 0
    total_workspaces = 0
    platform_stats = {}  # platform -> count
    
    # 列出模式
    if args.list:
        if platform_filter:
            plat_name = SUPPORTED_PLATFORMS.get(platform_filter, {}).get("name", platform_filter)
            print(f"📋 {plat_name} 所有工作区和对话列表\n")
        else:
            print("📋 CodeBuddy & WorkBuddy 所有工作区和对话列表\n")
        
        for base, plat_key in history_bases:
            plat_name = SUPPORTED_PLATFORMS.get(plat_key, {}).get("name", plat_key)
            for ws_hash in sorted(os.listdir(base)):
                ws_path = os.path.join(base, ws_hash)
                if not os.path.isdir(ws_path):
                    continue
                
                ws_name = get_workspace_display_name(ws_hash)
                index = load_conversation_index(ws_path)
                convs = index.get("conversations", [])
                
                if not convs:
                    continue
                
                total_workspaces += 1
                platform_stats[plat_name] = platform_stats.get(plat_name, 0) + 1
                print(f"📂 [{plat_name}] 工作区: {ws_name} ({ws_hash[:12]}…)")
                print(f"   对话数: {len(convs)}")
                
                for conv in sorted(convs, key=lambda c: c.get("lastMessageAt", ""), reverse=True):
                    name = conv.get("name", "")[:60] or "(无标题)"
                    last_msg = conv.get("lastMessageAt", "")[:10]
                    conv_id = conv.get("id", "")[:8]
                    print(f"   💬 [{last_msg}] {name} ({conv_id}…)")
                
                print()
        
        # 统计摘要
        if len(platform_stats) > 1:
            print(f"\n📊 共 {total_workspaces} 个工作区", end="")
            print(f" ({', '.join(f'{k}: {v}' for k, v in platform_stats.items())})")
        else:
            print(f"\n📊 共 {total_workspaces} 个工作区")
        return
    
    # 搜索对话
    if not args.memory_only:
        for base, plat_key in history_bases:
            plat_name = SUPPORTED_PLATFORMS.get(plat_key, {}).get("name", plat_key)
            for ws_hash in sorted(os.listdir(base)):
                ws_path = os.path.join(base, ws_hash)
                if not os.path.isdir(ws_path):
                    continue
                
                ws_name = get_workspace_display_name(ws_hash)
                
                # 工作区过滤
                if args.workspace:
                    if args.workspace.lower() not in ws_name.lower() and args.workspace.lower() not in ws_hash.lower():
                        continue
                
                index = load_conversation_index(ws_path)
                convs = index.get("conversations", [])
                total_workspaces += 1
                platform_stats[plat_name] = platform_stats.get(plat_name, 0) + 1
                
                for conv_meta in convs:
                    conv_id = conv_meta.get("id", "")
                    conv_name = conv_meta.get("name", "") or "(无标题)"
                    last_msg_at = conv_meta.get("lastMessageAt", "")
                    
                    # 日期过滤
                    if date_cutoff and last_msg_at:
                        try:
                            conv_time = datetime.fromisoformat(last_msg_at.replace('Z', '+00:00'))
                            if conv_time < date_cutoff:
                                continue
                        except Exception:
                            pass
                    
                    conv_dir = os.path.join(ws_path, conv_id)
                    if not os.path.isdir(conv_dir):
                        continue
                    
                    total_conversations += 1
                    messages = get_conversation_messages(conv_dir)
                    
                    for idx, msg_data in enumerate(messages):
                        role, text = extract_text_from_message(msg_data)
                        total_messages_scanned += 1
                        
                        # 角色过滤
                        if args.role and role != args.role:
                            continue
                        
                        matches = search_in_text(text, pattern, args.regex)
                        
                        if matches:
                            # 收集上下文消息
                            context_before = []
                            context_after = []
                            if args.context and args.context > 0:
                                for ci in range(max(0, idx - args.context), idx):
                                    cr, ct = extract_text_from_message(messages[ci])
                                    context_before.append({"role": cr, "text": ct[:200]})
                                for ci in range(idx + 1, min(len(messages), idx + 1 + args.context)):
                                    cr, ct = extract_text_from_message(messages[ci])
                                    context_after.append({"role": cr, "text": ct[:200]})
                            
                            result = {
                                "platform": plat_name,
                                "workspace": ws_name,
                                "workspace_hash": ws_hash,
                                "conversation_id": conv_id,
                                "conversation_name": conv_name,
                                "last_message_at": last_msg_at,
                                "message_index": idx,
                                "role": role,
                                "matches": matches,
                                "text_preview": text[:500] if len(text) > 500 else text,
                                "context_before": context_before,
                                "context_after": context_after,
                            }
                            results.append(result)
                            
                            if args.limit and len(results) >= args.limit:
                                break
                    
                    if args.limit and len(results) >= args.limit:
                        break
                
                if args.limit and len(results) >= args.limit:
                    break
    
    # 搜索项目级记忆
    memory_results = []
    if args.memory or args.memory_only:
        memory_results = search_memory_files(pattern, args.regex)
    
    # 输出结果
    if args.json:
        output = {
            "query": pattern,
            "stats": {
                "platforms": platform_stats,
                "workspaces_scanned": total_workspaces,
                "conversations_scanned": total_conversations,
                "messages_scanned": total_messages_scanned,
                "matches_found": len(results),
                "memory_matches": len(memory_results),
            },
            "results": results,
            "memory_results": memory_results,
        }
        print(json.dumps(output, ensure_ascii=False, indent=2))
    else:
        print_results(results, memory_results, pattern, total_workspaces, total_conversations, total_messages_scanned, args, platform_stats)


def search_memory_files(pattern, use_regex=False):
    """搜索项目级记忆文件（CodeBuddy + WorkBuddy）"""
    results = []
    
    # 搜索两个平台的项目目录
    home = os.path.expanduser("~")
    search_roots = [
        os.path.join(home, "CodeBuddy"),
        os.path.join(home, "WorkBuddy"),
    ]
    
    for root in search_roots:
        if not os.path.isdir(root):
            continue
        
        for dirpath, dirnames, filenames in os.walk(root):
            # 跳过 node_modules 等
            dirnames[:] = [d for d in dirnames if d not in ('node_modules', '.git', 'dist', '.vite', '__pycache__')]
            
            if '.codebuddy' not in os.path.basename(dirpath) and '.workbuddy' not in os.path.basename(dirpath):
                continue
            
            for fname in filenames:
                if not fname.endswith('.md'):
                    continue
                
                fpath = os.path.join(dirpath, fname)
                try:
                    with open(fpath, "r", encoding="utf-8") as f:
                        content = f.read()
                except Exception:
                    continue
                
                matches = search_in_text(content, pattern, use_regex)
                if matches:
                    # 计算相对路径
                    rel_path = os.path.relpath(fpath, home)
                    results.append({
                        "file": f"~/{rel_path}",
                        "matches": matches[:10],  # 最多10条匹配
                        "preview": content[:500],
                    })
    
    return results


def print_results(results, memory_results, pattern, total_ws, total_conv, total_msg, args, platform_stats=None):
    """格式化打印搜索结果"""
    
    # 平台统计
    plat_str = ""
    if platform_stats and len(platform_stats) > 1:
        plat_str = f" ({', '.join(f'{k}: {v}' for k, v in platform_stats.items())})"
    
    print(f"\n🔍 搜索: \"{pattern}\"")
    print(f"   扫描: {total_ws} 个工作区, {total_conv} 个对话, {total_msg} 条消息{plat_str}")
    print(f"   找到: {len(results)} 条对话匹配" + (f", {len(memory_results)} 条记忆匹配" if memory_results else ""))
    print("=" * 70)
    
    if not results and not memory_results:
        print("\n😔 未找到匹配结果")
        print("\n💡 建议:")
        print("   - 尝试更少/更短的关键词")
        print("   - 使用 --regex 进行模式匹配")
        print("   - 使用 --memory 同时搜索记忆文件")
        print("   - 使用 --platform codebuddy/workbuddy 指定平台")
        print("   - 使用 --list 查看所有可用对话")
        return
    
    # 按对话分组
    conv_groups = {}
    for r in results:
        key = r["conversation_id"]
        if key not in conv_groups:
            conv_groups[key] = {
                "platform": r.get("platform", ""),
                "workspace": r["workspace"],
                "conversation_name": r["conversation_name"],
                "last_message_at": r["last_message_at"],
                "conversation_id": r["conversation_id"],
                "matches": [],
            }
        conv_groups[key]["matches"].append(r)
    
    # 输出对话匹配
    for i, (conv_id, group) in enumerate(conv_groups.items()):
        if i > 0:
            print()
        
        date_str = group["last_message_at"][:10] if group["last_message_at"] else "未知"
        plat_tag = f"[{group['platform']}] " if group.get("platform") else ""
        print(f"\n📂 {plat_tag}[{group['workspace']}] 💬 {group['conversation_name']}")
        print(f"   🕐 {date_str} | ID: {conv_id[:12]}…")
        print(f"   匹配 {len(group['matches'])} 处:")
        
        for m in group["matches"]:
            role_icon = "👤" if m["role"] == "user" else "🤖"
            
            # 显示上下文（如果有）
            if m.get("context_before"):
                for ctx in m["context_before"]:
                    ctx_icon = "👤" if ctx["role"] == "user" else "🤖"
                    print(f"      {ctx_icon} {ctx['text'][:100]}{'…' if len(ctx['text']) > 100 else ''}")
            
            # 显示匹配内容
            for line_no, line_text in m["matches"][:3]:
                # 高亮关键词
                highlighted = line_text
                if not args.regex:
                    for kw in pattern.lower().split():
                        # 不区分大小写替换
                        idx = highlighted.lower().find(kw)
                        while idx != -1:
                            original = highlighted[idx:idx+len(kw)]
                            highlighted = highlighted[:idx] + f"【{original}】" + highlighted[idx+len(kw):]
                            idx = highlighted.lower().find(kw, idx + len(kw) + 2)
                
                print(f"   ➡️ {role_icon} {highlighted[:200]}{'…' if len(highlighted) > 200 else ''}")
            
            if len(m["matches"]) > 3:
                print(f"      … 还有 {len(m['matches']) - 3} 处匹配")
            
            # 显示后续上下文
            if m.get("context_after"):
                for ctx in m["context_after"]:
                    ctx_icon = "👤" if ctx["role"] == "user" else "🤖"
                    print(f"      {ctx_icon} {ctx['text'][:100]}{'…' if len(ctx['text']) > 100 else ''}")
    
    # 输出记忆文件匹配
    if memory_results:
        print(f"\n{'=' * 70}")
        print(f"\n📚 记忆文件匹配 ({len(memory_results)} 个文件):\n")
        for mr in memory_results:
            print(f"   📄 {mr['file']}")
            for line_no, line_text in mr["matches"][:3]:
                print(f"      ➡️ {line_text[:150]}{'…' if len(line_text) > 150 else ''}")
            if len(mr["matches"]) > 3:
                print(f"      … 还有 {len(mr['matches']) - 3} 处匹配")
    
    print(f"\n{'=' * 70}")
    print(f"✅ 搜索完成")


def main():
    parser = argparse.ArgumentParser(
        description="🔍 CodeBuddy & WorkBuddy 跨对话搜索引擎",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s 意图识别                    # 搜索包含"意图识别"的对话（所有平台）
  %(prog)s --platform codebuddy AIbot   # 只搜索 CodeBuddy 中的对话
  %(prog)s --platform workbuddy 需求    # 只搜索 WorkBuddy 中的对话
  %(prog)s AIbot 追问                  # 搜索同时包含"AIbot"和"追问"的消息
  %(prog)s --regex "意图.*分类"        # 正则搜索
  %(prog)s --role user 面试            # 只搜索用户消息
  %(prog)s --days 7 bug               # 搜索最近7天的对话
  %(prog)s --memory 设计规范           # 同时搜索记忆文件
  %(prog)s --memory-only 战绩页        # 只搜索记忆文件
  %(prog)s --list                      # 列出所有对话
  %(prog)s --context 1 皮肤            # 显示匹配消息前后各1条消息
        """
    )
    
    parser.add_argument("keywords", nargs="*", help="搜索关键词（多个关键词为 AND 逻辑）")
    parser.add_argument("--regex", action="store_true", help="使用正则表达式")
    parser.add_argument("--platform", choices=["codebuddy", "workbuddy"], help="只搜索指定平台（默认搜索全部）")
    parser.add_argument("--role", choices=["user", "assistant"], help="只搜索指定角色的消息")
    parser.add_argument("--days", type=int, help="只搜索最近 N 天的对话")
    parser.add_argument("--limit", type=int, default=30, help="最多返回结果数 (默认 30)")
    parser.add_argument("--context", type=int, default=0, help="显示匹配消息前后的上下文消息数")
    parser.add_argument("--workspace", type=str, help="按工作区名过滤")
    parser.add_argument("--memory", action="store_true", help="同时搜索项目级记忆文件")
    parser.add_argument("--memory-only", action="store_true", help="只搜索记忆文件")
    parser.add_argument("--list", action="store_true", help="列出所有工作区和对话")
    parser.add_argument("--verbose", action="store_true", help="显示详细信息")
    parser.add_argument("--json", action="store_true", help="输出 JSON 格式")
    
    args = parser.parse_args()
    search_conversations(args)


if __name__ == "__main__":
    main()
