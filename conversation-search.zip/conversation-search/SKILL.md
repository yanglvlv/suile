---
name: conversation-search
description: 跨对话全局搜索工具。在任意对话中搜索所有 CodeBuddy 和 WorkBuddy 历史对话内容、项目记忆文件。当用户说"搜索/找一下之前的对话"、"哪个对话里提到了X"、"之前讨论过的Y在哪"、"帮我找找关于Z的记录"、"我记得之前聊过"、"列出所有对话"等搜索历史内容的需求时使用此 skill。
version: 1.2.0
author: christoxu
---

# 跨对话搜索 Skill（CodeBuddy & WorkBuddy）

在任意对话中搜索 CodeBuddy 和 WorkBuddy 的所有历史对话内容和项目记忆文件。

## 核心能力

- **跨平台搜索**：同时搜索 CodeBuddy 和 WorkBuddy 的对话历史
- **平台过滤**：`--platform codebuddy/workbuddy` 指定只搜索某个平台
- **关键词搜索**：支持多关键词 AND 逻辑（空格分隔）
- **正则搜索**：`--regex` 参数支持正则表达式
- **角色过滤**：`--role user/assistant` 只搜索用户或 AI 消息
- **日期过滤**：`--days N` 只搜索最近 N 天
- **工作区过滤**：`--workspace <关键词>` 按工作区名过滤
- **记忆搜索**：`--memory` 同时搜索 `.codebuddy/memory/`、`.workbuddy/memory/` 和 `MEMORY.md`
- **对话列表**：`--list` 列出所有工作区和对话
- **上下文**：`--context N` 显示匹配消息前后 N 条消息
- **JSON 输出**：`--json` 输出结构化 JSON（便于程序化处理）

## 使用流程

### 1. 当用户要搜索历史对话时

运行搜索脚本：

```bash
python3 ~/.codebuddy/skills/conversation-search/scripts/search_conversations.py <关键词> [选项]
```

### 2. 常用搜索示例

```bash
# 基础关键词搜索（默认搜索所有平台）
python3 ~/.codebuddy/skills/conversation-search/scripts/search_conversations.py 意图识别

# 只搜索 CodeBuddy 中的对话
python3 ~/.codebuddy/skills/conversation-search/scripts/search_conversations.py --platform codebuddy AIbot

# 只搜索 WorkBuddy 中的对话
python3 ~/.codebuddy/skills/conversation-search/scripts/search_conversations.py --platform workbuddy 需求

# 多关键词 AND 搜索
python3 ~/.codebuddy/skills/conversation-search/scripts/search_conversations.py AIbot 追问系统

# 只搜索用户发言
python3 ~/.codebuddy/skills/conversation-search/scripts/search_conversations.py --role user 面试

# 搜索最近 7 天
python3 ~/.codebuddy/skills/conversation-search/scripts/search_conversations.py --days 7 bug修复

# 同时搜索记忆文件
python3 ~/.codebuddy/skills/conversation-search/scripts/search_conversations.py --memory 设计规范

# 只搜索记忆文件
python3 ~/.codebuddy/skills/conversation-search/scripts/search_conversations.py --memory-only 战绩页

# 正则搜索
python3 ~/.codebuddy/skills/conversation-search/scripts/search_conversations.py --regex "意图.*分类"

# 显示上下文
python3 ~/.codebuddy/skills/conversation-search/scripts/search_conversations.py --context 2 皮肤

# 列出所有对话
python3 ~/.codebuddy/skills/conversation-search/scripts/search_conversations.py --list

# JSON 格式输出（适合程序化处理）
python3 ~/.codebuddy/skills/conversation-search/scripts/search_conversations.py --json 王者荣耀
```

### 3. 理解搜索结果

搜索结果按对话分组显示：
- **📂 [平台] [工作区名]** — 平台标识 + 工作区名称
- **💬 对话标题** — 对话的标题（首条用户消息）
- **🕐 日期** — 对话最后活跃时间
- **ID** — 对话唯一标识（用于精确定位）
- **➡️ 👤/🤖** — 匹配的消息内容（用户/AI），关键词用【】高亮

### 4. 搜索范围

搜索覆盖以下数据源：

| 数据源 | macOS 路径 | Windows 路径 | 说明 |
|--------|-----------|--------------|------|
| CodeBuddy 对话 | `~/Library/Application Support/CodeBuddyExtension/Data/` | `%APPDATA%\CodeBuddyExtension\Data\` | CodeBuddy 所有工作区的对话消息 |
| WorkBuddy 对话 | `~/Library/Application Support/WorkBuddyExtension/Data/` | `%APPDATA%\WorkBuddyExtension\Data\` | WorkBuddy 所有工作区的对话消息 |
| 项目记忆 | `~/CodeBuddy/**/.codebuddy/memory/*.md` | `%USERPROFILE%\CodeBuddy\**\.codebuddy\memory\*.md` | CodeBuddy 每日工作日志 |
| 项目记忆 | `~/WorkBuddy/**/.workbuddy/memory/*.md` | `%USERPROFILE%\WorkBuddy\**\.workbuddy\memory\*.md` | WorkBuddy 每日工作日志 |
| 长期记忆 | `~/CodeBuddy/**/.codebuddy/MEMORY.md` | `%USERPROFILE%\CodeBuddy\**\.codebuddy\MEMORY.md` | CodeBuddy 项目长期记忆 |

### 5. 注意事项

- 搜索脚本基于 Python 3，macOS/Linux 自带，Windows 需确保 Python 3 已安装并加入 PATH
- **跨平台支持**：自动适配 Windows、macOS、Linux 数据路径
- 默认同时搜索 CodeBuddy 和 WorkBuddy 两个平台
- 首次运行会构建工作区映射缓存（约 1-2 秒）
- 默认最多返回 30 条结果，可通过 `--limit` 调整
- 大量对话时搜索可能需要数秒，耐心等待
- 搜索是只读操作，不会修改任何数据
